import 'package:flutter/material.dart';
import 'dart:async';
import 'package:barcode_scan/barcode_scan.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class MainPage extends StatefulWidget{

  @override
  _MainPageState createState() => new _MainPageState();
}

class _MainPageState extends State<MainPage> {

  @override void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context ){
    return Scaffold(
      appBar: new AppBar(title: Text("Simple Book Scanner", style: new TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.w600),)
        ,),
      body: new Center(child: new RawMaterialButton(onPressed: scanBarcode,
        child: new Icon(Icons.add_circle), shape: new CircleBorder(),
        elevation: 1.0,)),
    );
  }

  Future<String> scanBarcode () async{
    try {
      String barcode = await BarcodeScanner.scan();
      print("codice: " + barcode);
      return barcode;
    } on PlatformException catch(e) {
      if (e.code == BarcodeScanner.CameraAccessDenied){
        final Future<PermissionStatus> statusFuture =
            PermissionHandler().checkPermissionStatus(PermissionGroup.camera).then((PermissionStatus status) async {
              if(status != PermissionStatus.granted)  {
                final List<PermissionGroup> permissions = new List<PermissionGroup>();
                permissions.add(PermissionGroup.camera);
                final Map<PermissionGroup, PermissionStatus> permissionRequestResult =
                    await PermissionHandler().requestPermissions(permissions);
                PermissionHandler().checkPermissionStatus(PermissionGroup.camera).then((PermissionStatus status) async {
                  if(status != PermissionStatus.granted)  {
                    print("to use this feature accept permission.");
                  }
                });
                }
            });

      }
    }
  }

}